# Source ledger — Rhomax wavelength model selection

Compiled 2026-10-01. Separates three kinds of thing that are easy to blur: measurements
made by somebody else, results published by somebody else, results produced in this
workspace, and things merely proposed. Nothing in tier C may be cited as if it were
tier A or B.

## Tier A — original laboratory measurements (not ours)

| Item | Detail |
| --- | --- |
| Measurement | Peak absorption wavelength of microbial rhodopsins, in nanometres |
| Attribution | Inoue, K., Karasuyama, M., Nakamura, R. et al. "Exploration of natural red-shifted rhodopsins using a machine learning-based Bayesian experimental design." *Communications Biology* 4, 362 (2021). https://doi.org/10.1038/s42003-021-01878-9 |
| Provenance recorded upstream | "Lab generated; first hand." |
| Original distribution | Springer supplementary spreadsheet, `42003_2021_1878_MOESM3_ESM.xlsx` |
| Licence | CC-BY 4.0, per the article's rights link |
| How it reaches us | Repackaged by FLIP2 as `rhomax/by_wild_type.csv.gz` |
| Attribution file | https://flip.protein.properties/assets/splits/rhomax/README.md, sha256 `a966bc2c519732861c85a6f7105268f0329e503fc9104c0b966d565314c80d28` |

### What the released file does and does not carry

The decompressed CSV has exactly four columns: `sequence`, `target`, `set`, `validation`.

Therefore the following are **absent from the released data** and are not available to any
analysis built on it alone:

- wild-type background identity, despite the split being named `by_wild_type`
- any sequence or protein identifier, accession or name
- assay conditions (buffer, pH, temperature, expression host, detergent)
- which rows are chimeras versus natural sequences
- which rows are repeated measurements of the same protein
- homology or clustering metadata
- any statement of how repeated measurements were aggregated into one target

What can be established from the bytes, and was:

- 884 rows: 584 train, 116 validation, 184 test, matching the pinned manifest.
- Targets are integers in nm from 436 to 622, with 144 distinct values across all rows.
- Sequence lengths 227 to 365 residues; alphabet exactly the 20 standard amino acids.
- Zero exact sequence overlap between any two splits.
- Six sequences appear twice, all within train. Two of those pairs carry **different**
  targets: 498 and 517 nm, and 525 and 524 nm. These are the only direct evidence in the
  released file about measurement disagreement for an identical sequence, and a 19 nm
  disagreement is a useful floor to keep in mind. Four further pairs agree exactly.
  Whether these duplicates are repeated assays or repackaging artefacts is **not stated
  upstream and is not established here.**

### Supervised separation versus pretraining exposure

These are different claims and are kept apart.

- **Supervised separation:** the archive's own assignment holds validation and test rows
  out of probe fitting, and no exact sequence crosses a split boundary. Verified locally.
- **Pretraining exposure:** ESM-2 was pretrained on UniRef50. Whether any Rhomax protein
  or close homologue is in that corpus is **unreported upstream and not determined here**.
  The archived records say exactly this. A clean supervised split does not rule out
  pretraining exposure, and no claim either way is made.

## Tier B — upstream published artefacts (not ours, not reproduced)

| ID | Artefact | Locator | Verification |
| --- | --- | --- | --- |
| B1 | FLIP2 project site and source catalogue | https://flip.protein.properties/ | archived receipt, not refetched in this workspace |
| B2 | FLIP2 versioned data release | Zenodo record 18433203, `zenodo-18433203-v3` | gz sha256 `2d4bda26…`, MD5 `286781669d083104cc399ae8a561afc5`, decompressed CSV sha256 `8e78f6a1…`; all three verified from a fresh download here |
| B3 | FLIP baselines metric definitions | `baselines/aggregate.py` L131-135 at revision `62cace8735f5610e2743cf06ce0f944b37fffaa6` | revision pinned; metric behaviour reimplemented and checked against archived values |
| B4 | ESM-2 checkpoint `esm2_t6_8M_UR50D` | https://dl.fbaipublicfiles.com/fair-esm/models/esm2_t6_8M_UR50D.pt | sha256 `46f002a9870c9bdecd0ea887acb1f9a38a6b561e8f8bf8a6990b679b9d31b928`, verified on fresh download |
| B5 | ESM-2 checkpoint `esm2_t12_35M_UR50D` | https://dl.fbaipublicfiles.com/fair-esm/models/esm2_t12_35M_UR50D.pt | sha256 `7f21e80e61d16a71735163ef555d3009afb0c98da74c48e29df08606973cc55e`, verified on fresh download |
| B6 | ESM-2 usage and representation extraction | https://github.com/facebookresearch/esm at `2b369911bb5b4b0dda914521b9475cad1656b2ac` | archived receipt |

**FLIP2's own published baselines (one-hot ridge, fine-tuned models) are NOT used as
comparators here.** They were treated as discovery candidates only. Their target scaling
uses train plus validation rows, whereas every configuration in this article scales on
train alone, so the numbers are not protocol-compatible and comparing them would be
misleading. This is a deliberate omission, recorded rather than quietly skipped.

## Tier C — results produced in this workspace

Two distinct kinds, kept separate.

### C1. Reproduction of archived configurations

An independent reimplementation (`companion/`, not a copy of the benchmark SDK) was run on
a fresh Python 3.11.13 environment. It recomputes every archived metric for all five
historical configurations with absolute difference **0.0** at tolerance 1e-9.

| Configuration | Archived Spearman | Recomputed | Archived NDCG | Recomputed |
| --- | --- | --- | --- | --- |
| Training mean | undefined | undefined | 0.9206667522227658 | identical |
| Composition, 40 features | 0.41818225155801514 | identical | 0.954819941821582 | identical |
| Composition, 22 features | 0.41798958279508075 | identical | 0.9548154942827918 | identical |
| ESM-2 8M, layer 6 | -0.1463506755340845 | identical | 0.8964799835636942 | identical |
| ESM-2 35M, layer 12 | -0.2217595033467806 | identical | 0.9072580204736261 | identical |

The archived runs did not retain predictions in a redistributable form: the records keep
`predictions_sha256` but state that predictions, labels and embeddings stayed in ignored
local storage. So the predictions used for every new analysis here were **regenerated**,
not recovered. Because the archive's own row identifiers are random tokens generated at
preparation time, the archived `prepared_sha256` and `predictions_sha256` are not
reproducible by construction; the metrics are, and they are what was checked.

Receipt: `runs/results/panel-receipt.json`.

### C2. New analyses, first reported here

Specified in `evidence/frozen-exploratory-protocol.md` before any test error was computed.
Experiment name `rhomax-background-distance-exploratory-2026-10-01`. Exploratory, not
confirmatory. Includes: errors in nm; a nearest-training-sequence control; frozen
distance bins; reconstructed-group paired bootstrap; and two separate shortlist decisions.
Post-hoc additions (shortlist intervals, validation-interval feasibility) are labelled
`post_hoc_not_predeclared` in the output files and in the article.

Receipts: `runs/results/exploratory-analysis.json`, `runs/results/diagnostics.json`,
`runs/results/device-agreement.json`.

## Tier D — proposed, not done

Recorded so that absence is visible rather than inferred.

| Proposal | Status | Why |
| --- | --- | --- |
| Repeated held-out-background cross-validation | not attempted | the archive publishes no background labels, so held-out backgrounds cannot be defined without inventing them |
| Calibrated intervals with coverage under background shift | not claimed | one held-out validation set and no published grouping cannot establish coverage under shift |
| Aligned one-hot ridge | not attempted | no reproducible alignment and insertion policy was fixed; lengths differ by up to 138 residues |
| Larger or fine-tuned PLMs | not attempted | optional under the brief; the bounded panel already yields a defensible answer, and adding an untuned larger model would not change the conclusion about this split |
| Comparison against FLIP2's published baselines | not attempted | incompatible target-scaling protocol, as recorded in tier B |

## Licensing

- Rhomax measurements: CC-BY 4.0, attributed to Inoue et al. 2021 as above. No new
  licence is invented for this data and no source rows are redistributed in the code
  archive.
- ESM-2 weights: distributed by their upstream project under its own terms; weights are
  downloaded at run time and are not redistributed here.
- Original code written in this workspace: licence left as a PR review item, since no
  repository convention for companion-code licensing was found. This did not block work.
