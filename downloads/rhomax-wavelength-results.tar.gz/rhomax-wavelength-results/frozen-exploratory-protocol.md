# Frozen exploratory analysis protocol — Rhomax wavelength selection

Frozen: 2026-10-01, before any new test-set error, MAE, RMSE, interval, shortlist or
per-group statistic was computed in this workspace.

Experiment name: `rhomax-background-distance-exploratory-2026-10-01`.
This is a NEW, EXPLORATORY analysis. It is not the historical protocol, not preregistered,
and not confirmatory. It does not replace the five historical configurations.

## What was known at freeze time

Deliberately recorded so readers can judge what could have leaked into these choices.

Known:

1. The five archived configuration records and their published metrics (Spearman, NDCG,
   coverage 184/184), read from the pinned `rewire-benchmarks` snapshots.
2. The archive's structure, verified locally from the pinned source bytes:
   884 rows; columns `sequence,target,set,validation`; derived splits 584 train /
   116 validation / 184 test; lengths 227–365; alphabet exactly the 20 standard amino
   acids; targets 436–622 nm, 144 distinct values, mean 537.58 nm.
3. Zero exact sequence overlap between any two splits.
4. Six sequences duplicated within train, two of them with disagreeing targets.
5. A crude reconstruction of test background structure (equal length and Hamming
   distance <= 10% of length) yields 37 clusters: six of size 12–30 covering 125 of 184
   rows, and 22 singletons. Per-cluster mean targets span roughly 473–584 nm.

NOT known at freeze time: any model prediction, error, residual, interval or shortlist
computed in this workspace. No new model had been run.

## Hard constraint: the archive carries no background labels

`by_wild_type.csv.gz` has no wild-type identifier, no sequence identifier and no assay
metadata. The split is *named* `by_wild_type` upstream, but the released file does not
publish the grouping used to construct it.

Consequences, fixed now:

- Any grouping used below is a **declared reconstruction**, not the archive's grouping.
  It must always be described as such.
- "Repeated held-out-background" cross-validation is therefore **not supported** by this
  archive and will be recorded as an unsupported gate, not attempted and not estimated.
- Paired bootstrap over reconstructed groups is permitted only with the disclosure in
  section 5, because its effective sample size is driven by about six groups.

## 1. Stable row identifiers

The archive has no IDs. Define, for every row, `seq_id = sha256(sequence)[:12]` over the
uppercase sequence with no trailing whitespace. Shortlists and exported predictions use
`seq_id` plus the 0-based row index of the decompressed CSV (`csv_row`), both reported.
These are workspace-local identifiers and will be labelled as such; they are not upstream
accessions.

## 2. Distance measure to the training set (predeclared)

For each test row, `d_nn` = minimum over all 584 training rows of a normalised edit-free
distance defined as:

- If the training sequence has the same length: Hamming distance divided by length.
- If lengths differ: `1 - (identity of a global alignment-free bound)` is NOT used.
  Instead, for unequal lengths the pair is assigned distance `1.0`.

Rationale for the crude rule, fixed in advance: lengths differ by up to 138 residues
across backgrounds, no reproducible alignment or insertion policy has been fixed, and the
coordinator contract makes aligned features conditional on a defensible alignment. A
length-gated Hamming distance is fully reproducible and needs no alignment choice. Its
cost is that it cannot distinguish "slightly different length, otherwise near-identical"
from "unrelated"; this limitation is reported, not hidden.

`d_nn = 1.0` therefore means "no equal-length training sequence", i.e. no training
sequence in the same length class. This is a meaningful transfer signal in its own right
and will be reported as its own bin, not merged into a numeric gradient.

### Bins (predeclared, fixed edges)

| Bin | Definition |
| --- | --- |
| `near` | `d_nn` <= 0.05 |
| `mid` | 0.05 < `d_nn` <= 0.25 |
| `far` | 0.25 < `d_nn` < 1.0 |
| `no_length_match` | `d_nn` == 1.0 |

Bins with fewer than 10 test rows are reported with their count and are explicitly
marked as too small to support a difference claim. Bin edges will NOT be changed after
seeing errors. If a bin is empty that is reported as empty.

## 3. Reconstructed background groups (predeclared rule)

Group test rows by: equal sequence length AND single-linkage Hamming distance <= 10% of
length. This is exactly the rule already applied at freeze time, restated so it is fixed.
Groups are named `bg01..bgNN` ordered by descending size then ascending first `csv_row`.

Groups of size 1 are retained in per-group tables but excluded from any paired-bootstrap
resampling unit count claim, and the number excluded is always reported.

## 4. Metrics

Primary, in nanometres: MAE and RMSE on the 184 test rows.
Secondary: Spearman rho (undefined for a constant predictor; reported as "undefined",
never as 0).
Secondary, reported for historical comparability only: full-ranking NDCG using the
pinned upstream FLIP2 definition (`aggregate.py` L131–135 at revision
`62cace8735f5610e2743cf06ce0f944b37fffaa6`), which shifts target values by their
minimum, including when the minimum is positive, and ranks all 184 items.

NDCG relevance and tie policy, stated explicitly as required: gains are
`target - min(target)` over the scored set (so the minimum-wavelength item contributes
zero gain); all 184 items are ranked with no cut-off (`k=None`); gain is linear, not
exponential; and ties in the predicted score are resolved by scikit-learn's default
**tie-averaging** (`ndcg_score(..., ignore_ties=False)`), which assigns every member of a
tied block the mean gain of that block.

> **Amendment, 2026-10-01, before any new test error was computed.** This paragraph
> originally stated that ties were broken by `numpy.argsort` stable order, so that a
> constant predictor would inherit the archive's row order. That was wrong about the
> upstream implementation. On reading the pinned protocol source, scoring calls
> `sklearn.metrics.ndcg_score` with default arguments, which tie-averages. The correction
> is recorded rather than silently applied. It is a correction of fact about upstream code,
> not a change of analysis choice, and it was made before any error, residual or shortlist
> had been computed in this workspace. Consequence: a constant predictor's NDCG is
> deterministic and independent of row order, so it is reproducible, but it still reflects
> only the label distribution and carries no information about the model.

A constant predictor therefore receives a well-defined NDCG that depends only on the test
label distribution. This is why NDCG is secondary here: it can be high for a model that
makes no distinction between candidates at all.

## 5. Uncertainty

Bootstrap: 10,000 resamples, seed 20261001, resampling **reconstructed groups** with
replacement (cluster bootstrap), carrying all rows of a drawn group. Paired differences
between two configurations use the same group draws for both.

Reported: 2.5th and 97.5th percentiles of the MAE difference, and the fraction of
resamples favouring each configuration.

Disclosure fixed now: there are about 37 reconstructed groups of which 22 are singletons,
so roughly six groups carry most of the weight. Intervals from this procedure are wide and
approximate. A non-zero-excluding interval will be reported as **no supported difference**,
never as equivalence.

## 6. Prediction intervals and calibration

Permitted only as follows: fit on train, calibrate interval width on the 116 **unused**
validation rows, and report empirical coverage and mean width on test. Because the
validation rows are a *single* held-out set with no independent background replication,
and because the archive publishes no background labels, this cannot establish calibration
under background shift. If coverage is reported it is reported as a single observed number
with its binomial interval and the explicit statement that no guarantee is established.
If the validation rows turn out to be unusable for this purpose, the analysis is dropped
and recorded as an unsupported gate rather than approximated.

The historical protocol left validation unused. That remains preserved: the five historical
configurations are rerun with `validation_used = false`. Only this separately named
exploratory analysis touches validation labels.

## 7. Nearest-training-sequence control (new interpretable baseline)

Prediction for a test row = target of the single nearest training row under the section 2
distance. For `d_nn == 1.0` rows (no equal-length training sequence) the prediction is the
training mean, and the count of such fallbacks is reported. Ties at equal minimum distance
resolve to the lowest training `csv_row`. Deterministic, no fitting, no seed.

## 8. Shortlist utility (criterion fixed before evaluation)

Reader decision modelled: an engineer can express **k = 10** constructs.

Two distinct decisions are evaluated separately, because they are not the same task:

- **Decision A, desired band.** Target band 540–560 nm inclusive. Rank test rows by
  `|prediction - 550|` ascending, take the top 10, and report how many of those 10 have a
  measured target inside 540–560 nm (precision at 10), plus the mean absolute deviation of
  their measured targets from 550 nm.
- **Decision B, maximise red shift.** Rank test rows by prediction descending, take the
  top 10, and report the mean and maximum measured target of those 10.

Under a constant predictor all 184 test rows tie, so **no shortlist is defined at all**.
That is the honest result and it is reported as such: the training-mean configuration is
given no shortlist number. The reference it is replaced by is the expectation under uniform
random selection of 10 of the 184 rows, computed analytically from the measured targets
(for precision at 10 this is 10 times the band prevalence divided by 10, i.e. the band
prevalence itself; for Decision B the expected mean of a simple random sample of 10 is the
test-set mean). No seeded random draw is substituted for this expectation, so no seed
choice can flatter or penalise it.

Capacity k = 10, the band 540–560 nm and the 550 nm centre are fixed now and will not be
tuned. No other k or band will be reported as a headline; if any sensitivity check is run
it is labelled a sensitivity check.

## 9. Tuning and search budget

Zero. The five historical configurations are rerun exactly as recorded: fixed alpha 10
ridge, `fit_intercept=True`, no feature scaling, `StandardScaler` on training targets only,
train-only fitting. The new nearest-neighbour control has no hyperparameters. No alpha
search, no pooling search, no layer search, no checkpoint search will be run or reported.
If any such search is ever run it gets its own experiment name and is never compared with
the historical panel as if it were the same protocol.

## 10. Sufficient-evidence thresholds

- A difference in MAE is called **supported** only if the 95% paired cluster-bootstrap
  interval excludes zero AND the point difference is at least 2 nm.
- 2 nm is chosen because the archive itself contains an identical training sequence pair
  whose measured targets disagree by 19 nm and another by 1 nm, so differences far below
  the measurement disagreement visible in the data are not worth acting on. The 2 nm
  floor is deliberately permissive relative to that 19 nm disagreement and is a *reporting*
  threshold, not a claim about assay precision.
- Any bin or group with n < 10 is reported as insufficient for a difference claim.
- Spearman differences are not significance-tested; they are reported as point values with
  the cluster-bootstrap interval and described qualitatively.

## 11. Compute budget

Hard ceiling: 30 minutes wall-clock per configuration, CPU, batch size 4, torch threads 4,
torch seed 0, matching the archived settings. MPS is used only for a known-answer agreement
check against CPU, never for headline numbers. If a job would exceed the ceiling it is
abandoned and recorded, not extended.

## 12. Endpoint scope

The endpoint is peak absorption wavelength in nm, nothing else. No claim about activation
efficiency, expression, photostability, ion transport or cellular function follows from any
number in this protocol.

---

# Clarifications, 2 October 2026

Added after the implementation was complete and reviewed. The sections above are the
original frozen record and are **not** edited. Where an original sentence was ambiguous or
wrong about what the code does, the clarification below governs, and says so explicitly.
None of these changed a reported number: all twelve MAE and RMSE values still match an
independent recomputation to 7e-15, and all five historical configurations still reproduce
exactly.

## C1. Singleton groups are resampled, not excluded

Section 3 says groups of size 1 are "excluded from any paired-bootstrap resampling unit
count claim". That reads as though singletons are dropped from the bootstrap. They are not,
and were never intended to be.

What the code does, and what is correct: **every one of the 37 reconstructed groups is a
resampling unit**, including all 22 singletons. Dropping them would resample a different
and smaller population than the one being described, and would narrow the intervals by
discarding real rows.

What section 3 was reaching for, stated properly: a singleton cannot support a within-group
claim, and the *number* of independent groups is not a count of informative groups. Both
facts are reported alongside every interval, as `groups`, `singleton_groups` and
`largest_group_n`.

## C2. The NDCG tie policy and the shortlist tie-break are different rules

Section 8 refers to "the tie-break order of section 4". That cross-reference is wrong,
because section 4 governs a different operation.

- **Scoring (section 4)** uses scikit-learn's tie *averaging* for NDCG. Every member of a
  tied block receives the block's mean gain. No ordering is involved.
- **Shortlists (section 8)** rank with a stable sort, so equal predictions are taken in
  ascending row order.

These cannot be unified, because averaging produces a score and a shortlist needs an order.

Section 8 originally implied a constant predictor would still yield a shortlist, taken in
tie order. The implementation instead returns **no shortlist at all** for a constant
predictor, and that is the reporting decision retained here: a shortlist produced by row
order is an artefact of the file, not an output of the model, and reporting a precision for
it would invite exactly the misreading the protocol exists to prevent. The original frozen
wording is preserved above; this clarification records the decision actually taken.

## C3. Distance 1.0 is not a reliable sentinel, and no longer is one

The protocol uses distance 1.0 to mean "no equal-length training sequence". That is
ambiguous: an equal-length neighbour differing at *every* position also scores exactly 1.0,
and it is a genuine neighbour.

Checked against the pinned archive: the largest equal-length nearest distance is **0.9375**
on test and **0.9491** on validation, so the ambiguity never fires and no reported bin
count, MAE or interval changes. It can fire on user-supplied FASTA input.

The code now carries an explicit `has_length_match` flag, derived from whether a neighbour
exists rather than from the distance value, and that flag is authoritative for binning.
`distance_bin` still accepts the old sentinel when no flag is supplied, so previously saved
result files remain readable.

Related wording: sequence-derived clusters are a **declared reconstruction**. The released
archive publishes no wild-type label, so these are not documented backgrounds, and the
length-gated distance is a length-restricted measure that cannot see indels at all.

## C4. Shortlist capacity is validated, and precision uses the realised length

Section 8 fixes k = 10 against 184 rows, so capacity could never exceed the available rows
in the reported analysis. The general code path had no such guarantee and would have
divided by the requested capacity even when fewer rows existed, silently depressing
precision.

The implementation now refuses to form a shortlist, rather than returning a misleading
number, when: capacity is below 1; capacity exceeds the rows available; any prediction is
non-finite; or the predictor is constant. When a shortlist is formed, precision divides by
the **realised** shortlist length, which is also reported.

## C5. Three outcomes, kept apart

An earlier implementation collapsed "interval excludes zero but the effect is below the
2 nm reporting threshold" into the same bucket as "interval includes zero". These are
different findings and are now reported separately as `interval_excludes_zero`,
`meets_min_effect` and `supported_difference`.

A sub-threshold effect must be described as too small to act on, **not** as an absence of a
statistically supported difference.

## C6. Per-bin errors are descriptive only

Section 2 sets a minimum bin size of 10 below which no claim may be made. That minimum was
at one point reported under a field name implying the opposite, that n >= 10 made a bin
sufficient for a difference claim. It does not.

No paired interval is computed within any bin. **Every per-bin MAE is descriptive**,
including in the two bins of 87 and 92 rows. A between-method gap inside a bin is not a
supported difference anywhere in this article. The field is now `meets_min_bin_size` and
each bin record carries an explicit `evidence_status` saying so.
