# Results archive

Receipts and predictions from the runs reported in the article. Produced 2026-10-01.

## What is here

| File | Contents |
| --- | --- |
| `panel-receipt.json` | environment, timings, peak memory, per-configuration scores, and the reproduction check against the archived metrics |
| `test-predictions.json` | per-row predictions in nm for all six configurations, with local IDs and distance to the nearest training sequence |
| `test-predictions.npz` | the same, as arrays |
| `validation-predictions.npz` | validation-row predictions, used only by the post-hoc interval feasibility check |
| `exploratory-analysis.json` | frozen distance bins, per-group errors, paired cluster bootstrap, shortlists, and the labelled post-hoc section |
| `diagnostics.json` | prediction spread, the feature-scale effect on a fixed ridge alpha, and shortlist chance levels |
| `device-agreement.json` | CPU versus MPS known-answer check |
| `independent-recomputation.txt` | main metrics recomputed directly with scipy and scikit-learn, not via the package's own metrics module |
| `example.fasta`, `example-predictions.json` | the user-inference demonstration |

## What is deliberately NOT here

- **No sequences.** Rows are identified by `seq_id`, a 12-hex-character SHA-256 prefix of
  the sequence, and by `csv_row`, the 0-based row index of the decompressed archive. The
  amino-acid sequences themselves are not redistributed.
- **No model weights.** Download them from the upstream URLs recorded in the receipts.
- **No embeddings.** Regenerate with the companion; the command is in `companion/README.md`.

## Provenance and permissions for the `measured_nm` column

`measured_nm` carries 184 peak absorption wavelength measurements. These are not ours.

- Original measurements: Inoue, K., Karasuyama, M., Nakamura, R. et al.,
  *Communications Biology* 4, 362 (2021), https://doi.org/10.1038/s42003-021-01878-9
- Licence: **CC-BY 4.0**, which permits redistribution with attribution. That attribution
  is this section, and it travels with the archive.
- Route to here: repackaged by FLIP2 as `rhomax/by_wild_type.csv.gz`,
  `zenodo-18433203-v3`, decompressed CSV sha256
  `8e78f6a16cd5298131dca83130d4b94cc0ab4ae9c699460880441c19a65f656f`.
- No new licence is asserted over this data, and none may be inferred from its inclusion
  here. Redistributing the labels without the sequences is the minimum needed to make the
  predictions interpretable.

The `pred_*` columns are outputs of runs performed in this workspace.

## Identifier caveat

`seq_id` and `csv_row` are workspace-local. The released archive publishes no identifier,
accession or name for any row, so there is nothing upstream to map these to. Do not cite
them as if they were database accessions.

## Scope

Peak absorption wavelength in nanometres, on one split of one dataset, with frozen
encoders and a fixed alpha-10 ridge head. Nothing here establishes activation efficiency,
expression, photostability, ion transport or cellular function.
